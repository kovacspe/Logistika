﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using MinHeap;


namespace Logistika
{

    class Program
    {
        struct Solution
        {
            public List<string> instructions;
            public int cost;
            public Solution(List<string> instr,int cost)
            {
                this.cost = cost;
                instructions = instr;
            }
        }

        static Solution IterativeDeepeningAStar(Model m)
        {
            HashSet<State> exploredStates = new HashSet<State>();
            int limit = State.f(m.initialState,m);
            Console.WriteLine("Limit: {0}", limit);
            while (true)
            {
                Solution solution = IDA(m.initialState, m, limit,exploredStates);
                if (solution.instructions != null) return solution;
                else if (solution.cost == int.MaxValue) return solution;
                limit = solution.cost;
                exploredStates = new HashSet<State>();


            }

            
            

        }

        static Solution IDA(State currState, Model m, int limit,HashSet<State> exploredStates)
        {
            
            if (currState.IsFinal(m)) return new Solution(currState.WrapInstructions(), currState.currentPrice);
            if (State.f(currState, m) > limit) return new Solution(null, State.f(currState, m));
            //currState.PrintState(Console.Out, m);
            List<State> succesors = currState.ExpandState(m);
            exploredStates.Add(currState);
            int newLimit = int.MaxValue;
            foreach(State s in succesors)
            {

                if (exploredStates.Contains(s)) continue;
                var result = IDA(s, m,limit,exploredStates);
                if (result.instructions!=null)
                {
                   
                    return result;
                }
                //newLimit = Math.Min(newLimit, result.cost);
            }
           
            return new Solution(null, limit+200);
        }

        static List<string> AStar(State initialState, Model m)
        {
            int counter = 0;
            HashSet<State> exploredStates = new HashSet<State>();
            int maxSteps = m.places.Count * 3 * m.packages.Count; 
            MinHeap<State,int> heap = new MinHeap<State, int>();
            heap.Insert(initialState,0);

            exploredStates.Add(initialState);
            bool stop = false;
            while (heap.Count!=0)
            {
              
                State s = heap.ExtractMin().Key;
                //Console.WriteLine("-----------------------------CHOSED BEST----------------------------");
                //s.PrintState(Console.Out, m);
                var states = s.ExpandState(m);
                //Console.WriteLine(counter);
                foreach (State state in states)
                {
                    if (state.IsFinal(m))
                    {
                        List<string> lines = state.WrapInstructions();
                        return lines;
                    }
                    
                    if (!exploredStates.Contains(state))
                    {
                        //state.PrintState(Console.Out, m);
                        heap.Insert(state, state.GetHeuristicValue(m) + state.currentPrice);
                        exploredStates.Add(state);
                        ++counter;
                    }
                    
                }
            }
            return new List<string> { "CANNOT COMPLETE" };

        }

        static void Main(string[] args)
        {
            Model model = null;
            if (args.Length < 2) return;
            try
            {
                model = ParseModel(args[0]);
            }
            catch (IOException)
            {
                Console.WriteLine("Cannot read file: {0}", args[0]);
                return;
            }
            catch (FormatException)
            {
                Console.WriteLine("Error during parsing input file");
                return;
            }

            StreamWriter sw = new StreamWriter(args[1]);
            //List<string> lines = AStar(model.initialState, model);
            Solution solution = IterativeDeepeningAStar(model);
            if (solution.instructions==null)
            {
                Console.WriteLine("NO SOLUTION FOUND");
                return;
            }
            Console.WriteLine("==========================================\nOUTPUT");
            foreach (string line in solution.instructions)
            {
                sw.WriteLine(line);
                Console.WriteLine(line);
            }
            sw.Close();

        }

        static string ReadLine(StreamReader sr)
        {
            string s = sr.ReadLine();
            while (s == "" || s[0] == '%')
            {
                s = sr.ReadLine();
            }
            return s;
        }

        static Model ParseModel(string filename)
        {
            Model model = new Model();
            StreamReader sr = new StreamReader(filename);
            int numberOfCities = int.Parse(ReadLine(sr));
            int numberOfPlaces = int.Parse(ReadLine(sr));
            for (int i = 0; i < numberOfCities; i++)
            {
                model.cities.Add(i, new City(i));
            }

            for (int i = 0; i < numberOfPlaces; ++i)
            {
                int cityID = int.Parse(ReadLine(sr));
                City city = model.cities[cityID];
                Place placeToAdd = new Place(i, city);
                model.places.Add(i, placeToAdd);
                city.places.Add(placeToAdd);

            }
            // airports
            for (int i = 0; i < numberOfCities; i++)
            {
                int placeID = int.Parse(ReadLine(sr));
                Place p = model.places[placeID];
                p.isAirport = true;
                p.city.airport = p;
                model.Airports.Add(p);
            }

            // trucks
            int numberOfTrucks = int.Parse(ReadLine(sr));
            Place[] truckPositions = new Place[numberOfTrucks];
            for (int i = 0; i < numberOfTrucks; i++)
            {
                truckPositions[i] = model.places[int.Parse(ReadLine(sr))];
            }

            //planes
            int numberOfPlanes = int.Parse(ReadLine(sr));
            Place[] planesPositions = new Place[numberOfPlanes];
            for (int i = 0; i < numberOfPlanes; i++)
            {
                planesPositions[i] = model.places[int.Parse(ReadLine(sr))];
            }

            //packages
            int numberOfPackages = int.Parse(ReadLine(sr));
            List<Package>[] PackagesOnPositions = new List<Package>[numberOfPlaces];
            for (int i = 0; i < numberOfPlaces; i++)
            {
                PackagesOnPositions[i] = new List<Package>();
            }
            for (int i = 0; i < numberOfPackages; i++)
            {
                string[] info = ReadLine(sr).Split(' ');
                int startPosition = int.Parse(info[0]);
                Place target = model.places[int.Parse(info[1])];
                Package package = new Package(i, target);
                PackagesOnPositions[startPosition].Add(package);
                model.packages.Add(i,package);

            }

            State initialState = new State(truckPositions, planesPositions, PackagesOnPositions);
            initialState.currentPrice = 0;
            model.initialState = initialState;
           // State copy = initialState.MoveTruck(0, model.places[0]).MoveTruck(0, model.places[1]);
            //Console.WriteLine(initialState.GetHashCode());
            //Console.WriteLine(copy.GetHashCode());
            //initialState.PrintState(Console.Out, model);
            return model;
        }
    }
    class Model
    {
        public static int LoadTruckPrice = 2;
        public static int UnloadTruckPrice = 2;
        public static int TruckMovePrice = 17;
        public static int LoadPlanePrice = 14;
        public static int UnloadPlanePrice = 11;
        public static int PlaneMovePrice = 30;
        public static int PlaneEffectivePrice = 1;
        public static int TruckEffectivePrice = 4;
        public static int PlaneCapacity = 30;
        public static int TruckCapacity = 4;
        public static int TruckFullServicePrice = LoadTruckPrice + TruckEffectivePrice + UnloadTruckPrice;
        public static int PlaneFullServicePrice = LoadPlanePrice + PlaneEffectivePrice + UnloadPlanePrice;

        public List<Place> Airports;
        public Dictionary<int, Place> places;
        public Dictionary<int, City> cities;
        public Dictionary<int, Package> packages;

        public State initialState;

        public Model()
        {

            Airports = new List<Place>();
            places = new Dictionary<int, Place>();
            cities = new Dictionary<int, City>();
            packages = new Dictionary<int, Package>();
        }
    }

    class City
    {
        public int id;
        public List<Place> places;
        public Place airport;
        public City(int id)
        {
            this.id = id;
            airport = null;
            places = new List<Place>();
        }

    }

    class Place
    {
        public int id;
        public City city;
        public bool isAirport;

        public Place(int id, City city)
        {
            this.id = id;
            this.isAirport = false;
            this.city = city;
        }
    }

    class Package
    {
        public int id;
        public Place Target;

        public Package(int id, Place target)
        {
            this.id = id;
            Target = target;
        }
    }

    class State
    {
        
        public State predecessor;
        public int currentPrice;
        private string instructionAppliedOnPredecessor;
        Place[] AeroplaneAtPlace;
        Place[] TruckAtPlace;
        List<Package>[] PackagesOnTruck;
        List<Package>[] PackagesOnPlane;
        List<Package>[] PackagesOnPlace;

        public State(Place[] trucksPosition, Place[] planesPosition, List<Package>[] packagesOnPLaces)
        {
            
            AeroplaneAtPlace = planesPosition;
            TruckAtPlace = trucksPosition;
            PackagesOnTruck = new List<Package>[trucksPosition.Length];
            for (int i = 0; i < PackagesOnTruck.Length; i++)
            {
                PackagesOnTruck[i] = new List<Package>();
            }
            PackagesOnPlane = new List<Package>[planesPosition.Length];
            for (int i = 0; i < PackagesOnPlane.Length; i++)
            {
                PackagesOnPlane[i] = new List<Package>();
            }
            PackagesOnPlace = packagesOnPLaces;
        }

        public State(State s, string instruction, int instructionCost)
        {
            
            AeroplaneAtPlace = new Place[s.AeroplaneAtPlace.Length];
            s.AeroplaneAtPlace.CopyTo(AeroplaneAtPlace, 0);
            TruckAtPlace = new Place[s.TruckAtPlace.Length];
            s.TruckAtPlace.CopyTo(TruckAtPlace, 0);
            PackagesOnPlace = new List<Package>[s.PackagesOnPlace.Length];
            for (int i = 0; i < s.PackagesOnPlace.Length; i++)
            {
                PackagesOnPlace[i] = new List<Package>(s.PackagesOnPlace[i]);
            }

            PackagesOnTruck = new List<Package>[s.PackagesOnTruck.Length];
            for (int i = 0; i < s.PackagesOnTruck.Length; i++)
            {
                PackagesOnTruck[i] = new List<Package>(s.PackagesOnTruck[i]);
            }

            PackagesOnPlane = new List<Package>[s.PackagesOnPlane.Length];
            for (int i = 0; i < s.PackagesOnPlane.Length; i++)
            {
                PackagesOnPlane[i] = new List<Package>(s.PackagesOnPlane[i]);
            }
            instructionAppliedOnPredecessor = instruction;
            currentPrice = s.currentPrice + instructionCost;
            predecessor = s;
        }

        public static int f(State s,Model m)
        {
            return s.currentPrice + s.GetHeuristicValue(m);
        }

        public void WrapInstructions(List<string> instructions)
        {
            if (predecessor != null)
            {
                predecessor.WrapInstructions(instructions);
                instructions.Add(instructionAppliedOnPredecessor);
            }
        }

        public List<string> WrapInstructions()
        {
            List<string> instructions = new List<string>();
            if (predecessor != null)
                predecessor.WrapInstructions(instructions);
            instructions.Add(instructionAppliedOnPredecessor);
            return instructions;

        }

        public bool IsFinal(Model model)
        {
            return GetHeuristicValue(model) == 0;
        }

        private bool PlaceIsEmpty(Place p)
        {
            return PackagesOnPlace[p.id].Count == 0;
        }

        private bool IsInTruckTargets(int truckId, Place p)
        {
            foreach (var pack in PackagesOnTruck[truckId])
            {
                if (pack.Target == p) return true;
            }
            return false;
        }

        private bool IsInPlaneTargets(int planeId, Place p)
        {
            foreach (var pack in PackagesOnPlane[planeId])
            {
                if (pack.Target == p) return true;
            }
            return false;
        }

        public void PrintState(TextWriter tw, Model m)
        {
            tw.WriteLine("---------------------------------------------------\nPOPIS STAVU");
            tw.WriteLine("Po akcii: {0}", instructionAppliedOnPredecessor);
            tw.WriteLine("Cena stavu: {0}", currentPrice);
            tw.WriteLine("Heuristicky odhad: {0}", GetHeuristicValue(m));
            tw.WriteLine("\nPOLOHA DODAVEK");
            for (int i = 0; i < TruckAtPlace.Length; i++)
            {
                tw.WriteLine("{0} is on {1}", i, TruckAtPlace[i].id);
                tw.Write("\tLoad: ");
                foreach (var item in PackagesOnTruck[i])
                {
                    tw.Write("{0}, ", item.id);
                }
                tw.WriteLine();
            }

            tw.WriteLine("\nPOLOHA LETADEL");
            for (int i = 0; i < AeroplaneAtPlace.Length; i++)
            {
                tw.WriteLine("{0} is on {1}", i, AeroplaneAtPlace[i].id);
                tw.Write("\tLoad: ");
                foreach (var item in PackagesOnPlane[i])
                {
                    tw.Write("{0}, ", item.id);
                }
                tw.WriteLine();
            }

            tw.WriteLine("\nBALIKY NA MISTECH");
            for (int i = 0; i < PackagesOnPlace.Length; i++)
            {
                tw.WriteLine("On place {0} is :", i);
                foreach (var item in PackagesOnPlace[i])
                {
                    tw.Write("{0}, ", item.id);
                }
                tw.WriteLine();
            }
        }

        private static bool _PackagesEquals(List<Package>[] l1, List<Package>[] l2)
        {
            for (int i = 0; i < l1.Length; ++i)
            {
                if (l1[i].Count != l2[i].Count) return false;
                for (int j = 0; j < l1[i].Count; j++)
                {
                    if (l1[i][j] != l2[i][j]) return false;
                }
            }
            return true;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is State)) return false;
            State s = (State)obj;

            for (int i = 0; i <AeroplaneAtPlace.Length; ++i)
            {
                if (s.AeroplaneAtPlace[i] != AeroplaneAtPlace[i]) return false;
            }

            for (int i = 0; i <TruckAtPlace.Length; ++i)
            {
                if (s.TruckAtPlace[i] != TruckAtPlace[i]) return false;
            }

            if (!_PackagesEquals(PackagesOnPlace, s.PackagesOnPlace)) return false;
            if (!_PackagesEquals(PackagesOnPlane, s.PackagesOnPlane)) return false;
            if (!_PackagesEquals(PackagesOnTruck, s.PackagesOnTruck)) return false;

            return true;
        }

        private static int _GetHashCodeOfArray(Place[] places)
        {
            unchecked
            {
                int hash = 17;
                foreach(Place p  in places)
                {
                    hash = hash * 23 + p.id;
                }
                return hash;
            }
        }

        private static int _GetHashCodeOfPackages(List<Package>[] l)
        {
            unchecked
            {
                int hash = 11;
                foreach(var list in l)
                {
                    foreach(Package p in list)
                    {
                        hash = hash * 17 + p.id;
                    }
                }
                return hash;
            }
            
        }

        public override int GetHashCode()
        {
            unchecked 
            {
                int hash = 19;

                hash = hash * 31 + _GetHashCodeOfArray(TruckAtPlace);
                hash = hash * 31 + _GetHashCodeOfArray(AeroplaneAtPlace);
                hash = hash * 31 + _GetHashCodeOfPackages(PackagesOnPlace);
                hash = hash * 31 + _GetHashCodeOfPackages(PackagesOnPlane);
                hash = hash * 31 + _GetHashCodeOfPackages(PackagesOnTruck);
                return hash;
            };
        }

        public List<State> ExpandState(Model m)
        {
            List<State> expandedStates = new List<State>();
            
            //plane actions
            for (int i = 0; i < AeroplaneAtPlace.Length; ++i)
            {
                //plane load
                if (PackagesOnPlane[i].Count < Model.PlaneCapacity)
                    foreach (Package p in PackagesOnPlace[AeroplaneAtPlace[i].id])
                    {
                        if (p.Target.city != AeroplaneAtPlace[i].city)
                            expandedStates.Add(LoadPackageOnAeroPlane(p, i));
                    }
                //plane unload
                foreach (Package p in PackagesOnPlane[i])
                {
                    expandedStates.Add(UnLoadPackageFromAeroplane(p, i));
                }

                // plane move
                foreach (Place p in m.Airports)
                {
                    if (!(p == AeroplaneAtPlace[i]) && (!PlaceIsEmpty(p) || IsInPlaneTargets(i, p)))
                    {
                        expandedStates.Add(MoveAeroplane(i, p));
                    }
                }
            }

            //truck actions
            for (int i = 0; i < TruckAtPlace.Length; ++i)
            {
                //truck load
                if (PackagesOnTruck[i].Count < Model.TruckCapacity)
                    foreach (Package p in PackagesOnPlace[TruckAtPlace[i].id])
                    {
                        if (!TruckAtPlace[i].isAirport || (p.Target.city == TruckAtPlace[i].city))
                            expandedStates.Add(LoadPackageOnTruck(p, i));
                    }
                //truck unload
                foreach (Package p in PackagesOnTruck[i])
                {
                    expandedStates.Add(UnLoadPackageFromTruck(p, i));
                }

                // plane move
                foreach (Place p in TruckAtPlace[i].city.places)
                {
                    if (!(p == TruckAtPlace[i]) && (!PlaceIsEmpty(p) || IsInTruckTargets(i, p)) && !(PackagesOnTruck[i].Count==0 && PlaceIsEmpty(p)))
                    {
                        expandedStates.Add(MoveTruck(i, p));
                    }
                }
            }



            return expandedStates;
        }

        public State MoveTruck(int TruckID, Place p)
        {
            State newState = new State(this, "drive " + TruckID + " " + p.id, Model.TruckMovePrice);
            newState.TruckAtPlace[TruckID] = p;

            //automatically unload all packages which are in target position
            foreach (Package package in PackagesOnTruck[TruckID])
            {
                if (package.Target == p)
                {

                    newState = newState.UnLoadPackageFromTruck(package, TruckID);
                    // not interesting for the task from this point
                    newState.PackagesOnPlace[p.id].Remove(package);
                }
                else if (package.Target.city!=p.city && p.isAirport)
                {
                    newState = newState.UnLoadPackageFromTruck(package, TruckID);
                }
                
            }

            return newState;
        }

        public State MoveAeroplane(int AeroplaneID, Place p)
        {
            State newState = new State(this, "fly " + AeroplaneID + " " + p.id, Model.PlaneMovePrice);
            newState.AeroplaneAtPlace[AeroplaneID] = p;

            //automatically unload all packages which are in target position
            foreach (Package package in PackagesOnPlane[AeroplaneID])
            {
                if (package.Target.city == p.city)
                {

                    newState = newState.UnLoadPackageFromAeroplane(package, AeroplaneID);

                    if (package.Target == p)
                    {
                        // not interesting for the task from this point
                        newState.PackagesOnPlace[p.id].Remove(package);
                    }
                }
            }

            return newState;
        }

        public State LoadPackageOnTruck(Package package, int TruckID)
        {
            State newState = new State(this, "load " + TruckID + " " + package.id, Model.LoadTruckPrice);
            newState.PackagesOnPlace[TruckAtPlace[TruckID].id].Remove(package);
            newState.PackagesOnTruck[TruckID].Add(package);
            return newState;
        }


        public State UnLoadPackageFromTruck(Package package, int TruckID)
        {
            State newState = new State(this, "unload " + TruckID + " " + package.id, Model.UnloadTruckPrice);
            newState.PackagesOnTruck[TruckID].Remove(package);
            newState.PackagesOnPlace[TruckAtPlace[TruckID].id].Add(package);
            return newState;
        }

        public State LoadPackageOnAeroPlane(Package package, int PlaneID)
        {
            State newState = new State(this, "pickUp " + PlaneID + " " + package.id, Model.LoadPlanePrice);
            newState.PackagesOnPlace[AeroplaneAtPlace[PlaneID].id].Remove(package);
            newState.PackagesOnPlane[PlaneID].Add(package);
            return newState;
        }

        public State UnLoadPackageFromAeroplane(Package package, int PlaneID)
        {
            State newState = new State(this, "dropOff " + PlaneID + " " + package.id, Model.UnloadPlanePrice);
            newState.PackagesOnPlane[PlaneID].Remove(package);
            newState.PackagesOnPlace[AeroplaneAtPlace[PlaneID].id].Add(package);
            return newState;
        }

        public int GetHeuristicValue(Model model)
        {
            int sum = 0;
            for (int i = 0; i < PackagesOnPlace.Length; i++)
            {
                foreach (var p in PackagesOnPlace[i])
                {
                    if (p.Target.id == i)
                    {
                        continue;
                    }
                    else if (p.Target.city == model.places[i].city)
                    {
                        sum += Model.TruckFullServicePrice;
                    }
                    else if (model.places[i].isAirport)
                    {
                        if (p.Target.isAirport)
                            sum += Model.PlaneFullServicePrice;
                        else
                            sum += Model.PlaneFullServicePrice + Model.TruckFullServicePrice;
                    }
                    else
                    {
                        if (p.Target.isAirport)
                            sum += Model.PlaneFullServicePrice + Model.TruckFullServicePrice;
                        else
                            sum += Model.PlaneFullServicePrice + 2 * Model.TruckFullServicePrice;
                    }
                }
            }

            // packages on planes
            for (int i = 0; i < PackagesOnPlane.Length; i++)
            {
                foreach (var p in PackagesOnPlane[i])
                {
                    sum += Model.UnloadPlanePrice;
                    if (p.Target.city == AeroplaneAtPlace[i].city)
                    {

                        if (p.Target != AeroplaneAtPlace[i])
                            sum += Model.PlaneEffectivePrice;
                    }
                    else
                    {
                        sum += Model.PlaneEffectivePrice;
                        if (p.Target.isAirport)
                            sum += Model.TruckFullServicePrice;
                    }
                }
            }

            //packages on trucks
            for (int i = 0; i < PackagesOnTruck.Length; i++)
            {
                foreach (var p in PackagesOnTruck[i])
                {
                    sum += Model.UnloadTruckPrice;
                    if (p.Target.city == TruckAtPlace[i].city)
                    {

                        if (p.Target != TruckAtPlace[i])
                            sum += Model.TruckEffectivePrice;
                    }
                    else
                    {
                        sum += Model.PlaneFullServicePrice;
                        if (p.Target.isAirport)
                            sum += Model.TruckFullServicePrice;
                    }
                }
            }

            return sum;
        }



    }
}
